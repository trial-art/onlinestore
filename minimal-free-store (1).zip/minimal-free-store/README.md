# FORMA — Free Static Storefront

A responsive sample storefront made with plain HTML, CSS, and JavaScript. It has product cards, category filters, search, a cart, quantity controls, and a manual order request form.

## Important limitations

- No online payments are collected.
- The checkout prepares an email with the order details; the customer must send it.
- Change `CONTACT_EMAIL` in `script.js` to your actual email before publishing.
- The sample products, names, descriptions, prices, and illustrations are placeholders. Replace them with your own products.
- This is a front-end-only site. Orders are not automatically saved to a database and are not sent to you without the customer sending the prepared email.
- Product prices are examples in MAD. Confirm shipping and final totals with customers.
- The Google Fonts import is optional; if it cannot load, system fonts are used.

## Files

- `index.html` — page structure
- `styles.css` — design and responsive layout
- `script.js` — sample products, search, filters, cart, and manual ordering

## Test locally

Open `index.html` in your browser. No build tools are needed.

## Publish on Netlify for $0

1. Visit https://app.netlify.com/ and create an account.
2. In the Netlify dashboard, choose **Add new site** / **Deploy manually** (wording may vary).
3. Drag the entire `minimal-free-store` folder (or a ZIP of its contents) into the manual deploy drop zone.
4. Wait for the deploy to finish. Netlify will provide a public `*.netlify.app` URL.
5. Open that URL on your phone and computer to test the store.
6. To update the site, deploy the updated folder again.
7. In `script.js`, replace `hello@example.com` with your real shop email and change the products/prices before sharing it.

Netlify's free plan and quotas can change, so check the current plan terms. You do not need to buy a custom domain for the Netlify subdomain.

## Add your own products

In `script.js`, edit the `PRODUCTS` array. Each product uses:
- `id`: unique number
- `name`: product name
- `category`: `Home`, `Accessories`, or `Lifestyle` (or add a new category and button)
- `price`: number
- `badge`: optional small label
- `description`: short description
- `color`: hex color for the placeholder illustration
- `shape`: one of the built-in illustration names

To use actual product photos, replace each illustration in the product card with an image element and add image files in this folder. Keep images optimized so the site loads quickly.

## Privacy note

The order form asks customers for personal contact and delivery details and opens an email draft on their own device. Add a privacy notice and collect only information you genuinely need. Do not ask customers to enter card details into this static site.
