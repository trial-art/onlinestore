/*
  FORMA sample storefront.
  CUSTOMIZE THESE SETTINGS:
  1. Change STORE_NAME and CONTACT_EMAIL.
  2. Edit PRODUCTS to add your real products, prices, categories and colors.
  3. For manual orders, customers' email app opens with the order details.
     No payment is collected by this demo.
*/
const STORE_NAME = "FORMA";
const CONTACT_EMAIL = "hello@example.com"; // Replace with your real shop email.
const CURRENCY = "MAD"; // Change if needed, e.g. USD, EUR.
const LOCALE = "en-MA";

const PRODUCTS = [
  { id: 1, name: "Sculptural Ceramic Vase", category: "Home", price: 189, badge: "Bestseller", description: "A tactile, sculptural accent for your favorite corner.", color: "#d8c8b5", shape: "vase" },
  { id: 2, name: "Everyday Canvas Tote", category: "Accessories", price: 129, badge: "Everyday essential", description: "A roomy, durable tote for the things you carry daily.", color: "#c5b59e", shape: "tote" },
  { id: 3, name: "Soft Cotton Throw", category: "Home", price: 249, badge: "", description: "A soft, textured layer for slow mornings and quiet evenings.", color: "#d9d5ca", shape: "throw" },
  { id: 4, name: "Minimal Desk Tray", category: "Lifestyle", price: 99, badge: "New", description: "A simple catch-all for your keys, jewelry, and small essentials.", color: "#b7a28e", shape: "tray" },
  { id: 5, name: "Daily Carry Pouch", category: "Accessories", price: 79, badge: "", description: "A compact pouch to keep everyday essentials together.", color: "#d3b6a4", shape: "pouch" },
  { id: 6, name: "Stoneware Cup", category: "Home", price: 89, badge: "", description: "A handmade-look cup for your daily coffee or tea ritual.", color: "#c7b6a0", shape: "cup" },
  { id: 7, name: "Pocket Notebook Set", category: "Lifestyle", price: 59, badge: "", description: "A set of simple notebooks for notes, lists, and ideas.", color: "#c8c7ba", shape: "notebook" },
  { id: 8, name: "Classic Key Ring", category: "Accessories", price: 45, badge: "", description: "A small, useful everyday accessory with a clean finish.", color: "#b7a18c", shape: "keyring" }
];

const state = { cart: {}, category: "All", search: "" };
const $ = (selector) => document.querySelector(selector);
const productGrid = $("#product-grid");
const cartDrawer = $("#cart-drawer");
const backdrop = $("#drawer-backdrop");
const orderDialog = $("#order-dialog");

function money(amount) {
  try {
    return new Intl.NumberFormat(LOCALE, { style: "currency", currency: CURRENCY, maximumFractionDigits: 2 }).format(amount);
  } catch {
    return `${amount.toFixed(2)} ${CURRENCY}`;
  }
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}

// Product illustrations are drawn locally in SVG, so the demo does not need paid image assets.
function illustration(product, extraClass = "") {
  const c = product.color;
  let object = "";
  switch (product.shape) {
    case "vase":
      object = `<ellipse cx="160" cy="325" rx="80" ry="14" fill="#000" opacity=".08"/><path d="M135 95 L185 95 L188 133 C190 154 218 175 221 218 L230 294 Q160 326 90 294 L99 218 C102 175 130 154 132 133 Z" fill="${c}"/><rect x="136" y="72" width="48" height="33" rx="5" fill="${c}"/><ellipse cx="160" cy="73" rx="24" ry="6" fill="#b7a28d"/>`;
      break;
    case "tote":
      object = `<ellipse cx="160" cy="326" rx="90" ry="12" fill="#000" opacity=".08"/><path d="M105 140 Q160 110 215 140 L235 306 Q160 324 85 306 Z" fill="${c}"/><path d="M125 147 C120 65 200 65 195 147" fill="none" stroke="#8c7964" stroke-width="12" stroke-linecap="round"/><path d="M120 160 L200 160" stroke="#e5d8c7" stroke-width="2" opacity=".65"/>`;
      break;
    case "throw":
      object = `<ellipse cx="160" cy="319" rx="110" ry="12" fill="#000" opacity=".07"/><path d="M62 119 L251 96 L269 286 L82 310 Z" fill="${c}"/><path d="M77 132 L244 112 M82 157 L247 137 M85 183 L250 163 M88 209 L253 189 M91 235 L256 215 M94 261 L259 241" stroke="#f7f3eb" stroke-width="3" opacity=".5"/><path d="M84 310 L78 329 M102 307 L98 329 M120 303 L118 325 M138 301 L138 323 M156 298 L158 320 M174 296 L178 318 M192 293 L198 315 M210 291 L218 313 M228 288 L238 310" stroke="${c}" stroke-width="5"/>`;
      break;
    case "tray":
      object = `<ellipse cx="160" cy="286" rx="115" ry="25" fill="#000" opacity=".08"/><path d="M50 200 Q160 168 270 200 L244 277 Q160 302 76 277 Z" fill="${c}"/><ellipse cx="160" cy="200" rx="110" ry="28" fill="#d8c5b0"/><ellipse cx="160" cy="200" rx="88" ry="17" fill="#b7a28e"/>`;
      break;
    case "pouch":
      object = `<ellipse cx="160" cy="301" rx="93" ry="13" fill="#000" opacity=".08"/><rect x="70" y="130" width="180" height="155" rx="18" fill="${c}"/><path d="M80 151 L240 151" stroke="#8e7463" stroke-width="5"/><rect x="111" y="145" width="138" height="8" rx="3" fill="#9e846f"/><circle cx="230" cy="149" r="5" fill="#eee2d2"/>`;
      break;
    case "cup":
      object = `<ellipse cx="145" cy="292" rx="75" ry="12" fill="#000" opacity=".08"/><path d="M80 135 L205 135 L193 270 Q142 295 92 270 Z" fill="${c}"/><ellipse cx="142" cy="135" rx="63" ry="16" fill="#e5d8c7"/><ellipse cx="142" cy="136" rx="48" ry="9" fill="#8e7d6b"/><path d="M205 160 Q265 155 245 215 Q233 246 198 230" fill="none" stroke="${c}" stroke-width="18"/>`;
      break;
    case "notebook":
      object = `<ellipse cx="160" cy="302" rx="100" ry="12" fill="#000" opacity=".08"/><g transform="rotate(-9 150 210)"><rect x="80" y="105" width="128" height="195" rx="4" fill="#aaa99d"/><rect x="94" y="94" width="128" height="195" rx="4" fill="${c}"/><path d="M115 132 L199 132 M115 145 L189 145" stroke="#f4f0e7" stroke-width="3" opacity=".8"/></g>`;
      break;
    case "keyring":
      object = `<ellipse cx="160" cy="292" rx="72" ry="12" fill="#000" opacity=".08"/><circle cx="130" cy="160" r="40" fill="none" stroke="#b08d64" stroke-width="12"/><path d="M158 188 L216 246 Q226 256 216 266 L200 282 Q191 290 181 280 L154 253" fill="none" stroke="${c}" stroke-width="22" stroke-linecap="round"/><rect x="177" y="231" width="54" height="24" rx="7" transform="rotate(45 177 231)" fill="#d7c7b4"/>`;
      break;
    default:
      object = `<rect x="80" y="100" width="160" height="200" rx="12" fill="${c}"/>`;
  }
  return `<svg class="${extraClass}" viewBox="0 0 320 360" role="img" aria-label="${escapeHTML(product.name)} illustration" xmlns="http://www.w3.org/2000/svg"><rect width="320" height="360" fill="${c}" opacity=".12"/>${object}</svg>`;
}

function filteredProducts() {
  const query = state.search.trim().toLowerCase();
  return PRODUCTS.filter(p => (state.category === "All" || p.category === state.category) &&
    (!query || `${p.name} ${p.description} ${p.category}`.toLowerCase().includes(query)));
}

function renderProducts() {
  const items = filteredProducts();
  productGrid.innerHTML = items.map(p => `
    <article class="product-card">
      <div class="product-image">
        ${illustration(p)}
        ${p.badge ? `<span class="product-badge">${escapeHTML(p.badge)}</span>` : ""}
        <button class="quick-add" data-add="${p.id}" aria-label="Add ${escapeHTML(p.name)} to bag">Add to bag +</button>
      </div>
      <div class="product-info">
        <div><p class="product-name">${escapeHTML(p.name)}</p><p class="product-category">${escapeHTML(p.category)}</p></div>
        <span class="product-price">${money(p.price)}</span>
      </div>
    </article>`).join("");
  $("#empty-state").hidden = items.length > 0;
}

function cartQuantity() {
  return Object.values(state.cart).reduce((sum, qty) => sum + qty, 0);
}
function cartSubtotal() {
  return PRODUCTS.reduce((sum, p) => sum + p.price * (state.cart[p.id] || 0), 0);
}
function addToCart(id) {
  state.cart[id] = (state.cart[id] || 0) + 1;
  renderCart();
  showToast("Added to your bag");
}
function changeQuantity(id, delta) {
  const next = (state.cart[id] || 0) + delta;
  if (next <= 0) delete state.cart[id]; else state.cart[id] = next;
  renderCart();
}
function removeFromCart(id) {
  delete state.cart[id];
  renderCart();
}
function renderCart() {
  const qty = cartQuantity();
  $("#cart-count").textContent = qty;
  $("#drawer-count").textContent = `(${qty})`;
  $("#cart-empty").hidden = qty !== 0;
  $("#cart-summary").hidden = qty === 0;
  $("#cart-subtotal").textContent = money(cartSubtotal());
  $("#order-total").textContent = money(cartSubtotal());
  $("#cart-items").innerHTML = PRODUCTS.filter(p => state.cart[p.id]).map(p => `
    <div class="cart-line">
      <div class="cart-thumb">${illustration(p)}</div>
      <div>
        <p class="cart-line-name">${escapeHTML(p.name)}</p>
        <p class="cart-line-price">${money(p.price)}</p>
        <div class="qty-control">
          <button data-qty="${p.id}" data-delta="-1" aria-label="Decrease quantity">−</button>
          <span>${state.cart[p.id]}</span>
          <button data-qty="${p.id}" data-delta="1" aria-label="Increase quantity">+</button>
          <button class="remove-item" data-remove="${p.id}">Remove</button>
        </div>
      </div>
      <strong class="cart-line-price">${money(p.price * state.cart[p.id])}</strong>
    </div>`).join("");
}
function openCart() {
  cartDrawer.classList.add("open");
  cartDrawer.setAttribute("aria-hidden", "false");
  backdrop.hidden = false;
  document.body.classList.add("locked");
  $("#close-cart").focus();
}
function closeCart() {
  cartDrawer.classList.remove("open");
  cartDrawer.setAttribute("aria-hidden", "true");
  backdrop.hidden = true;
  document.body.classList.remove("locked");
}
let toastTimeout;
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove("show"), 2200);
}

function buildOrderText(data) {
  const lines = PRODUCTS.filter(p => state.cart[p.id]).map(p =>
    `- ${p.name} × ${state.cart[p.id]} = ${money(p.price * state.cart[p.id])}`);
  return [
    `Hello ${STORE_NAME}, I'd like to place an order request:`,
    "",
    ...lines,
    "",
    `Estimated item subtotal: ${money(cartSubtotal())}`,
    "",
    `Name: ${data.name}`,
    `Phone/WhatsApp: ${data.phone}`,
    `City: ${data.city}`,
    `Delivery address: ${data.address}`,
    `Extra notes: ${data.notes || "None"}`,
    "",
    "Please confirm availability, shipping cost, final total, and payment method before processing."
  ].join("\n");
}

$("#year").textContent = new Date().getFullYear();
$("#open-cart").addEventListener("click", openCart);
$("#close-cart").addEventListener("click", closeCart);
$("#continue-shopping").addEventListener("click", closeCart);
backdrop.addEventListener("click", closeCart);
$("#search-input").addEventListener("input", event => {
  state.search = event.target.value;
  renderProducts();
});
$("#category-row").addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (!button) return;
  state.category = button.dataset.category;
  document.querySelectorAll(".category").forEach(b => b.classList.toggle("active", b === button));
  renderProducts();
});
productGrid.addEventListener("click", event => {
  const button = event.target.closest("[data-add]");
  if (button) addToCart(Number(button.dataset.add));
});
$("#cart-items").addEventListener("click", event => {
  const qtyButton = event.target.closest("[data-qty]");
  const removeButton = event.target.closest("[data-remove]");
  if (qtyButton) changeQuantity(Number(qtyButton.dataset.qty), Number(qtyButton.dataset.delta));
  if (removeButton) removeFromCart(Number(removeButton.dataset.remove));
});
$("#checkout-button").addEventListener("click", () => {
  if (!cartQuantity()) return;
  closeCart();
  orderDialog.showModal();
});
$("#close-order").addEventListener("click", () => orderDialog.close());
orderDialog.addEventListener("click", event => {
  if (event.target === orderDialog) orderDialog.close();
});
$("#order-form").addEventListener("submit", event => {
  event.preventDefault();
  const error = $("#form-error");
  error.hidden = true;
  if (!cartQuantity()) {
    error.textContent = "Your bag is empty. Add an item before placing an order.";
    error.hidden = false;
    return;
  }
  const formData = new FormData(event.currentTarget);
  const data = Object.fromEntries(formData.entries());
  const subject = encodeURIComponent(`Order request from ${data.name} — ${STORE_NAME}`);
  const body = encodeURIComponent(buildOrderText(data));
  const mailto = `mailto:${encodeURIComponent(CONTACT_EMAIL)}?subject=${subject}&body=${body}`;

  // Email apps may not be configured. Offer a copyable order summary as a fallback.
  const link = document.createElement("a");
  link.href = mailto;
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  link.remove();

  const fallback = document.createElement("div");
  fallback.className = "order-fallback";
  fallback.style.cssText = "margin-top:14px;padding:14px;background:#f0eee8;font-size:11px;line-height:1.7;white-space:pre-wrap;overflow-wrap:anywhere";
  fallback.textContent = `If your email app didn't open, copy this order and send it to ${CONTACT_EMAIL}:\n\n${buildOrderText(data)}`;
  const old = $("#order-form .order-fallback");
  if (old) old.remove();
  $("#order-form").appendChild(fallback);
  const copyButton = document.createElement("button");
  copyButton.type = "button";
  copyButton.className = "button button-outline";
  copyButton.style.cssText = "width:100%;margin-top:10px";
  copyButton.textContent = "Copy order details";
  copyButton.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(buildOrderText(data));
      copyButton.textContent = "Copied — paste into your message";
    } catch {
      copyButton.textContent = "Select and copy the order text above";
    }
  });
  $("#order-form").appendChild(copyButton);
  showToast("Order email prepared — please send it to confirm");
});
$("#contact-link").href = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent(`Hello ${STORE_NAME}`)}`;
renderProducts();
renderCart();
